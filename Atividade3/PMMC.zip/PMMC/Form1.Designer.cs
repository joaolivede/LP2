﻿namespace PMMC
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbtnHomem = new System.Windows.Forms.RadioButton();
            this.rdbtnMulher = new System.Windows.Forms.RadioButton();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.mskTxtPeso = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtAltura = new System.Windows.Forms.MaskedTextBox();
            this.txtPesoIdeal = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Peso atual";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Altura";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbtnHomem);
            this.groupBox1.Controls.Add(this.rdbtnMulher);
            this.groupBox1.Location = new System.Drawing.Point(210, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(107, 83);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            // 
            // rdbtnHomem
            // 
            this.rdbtnHomem.AutoSize = true;
            this.rdbtnHomem.Location = new System.Drawing.Point(3, 39);
            this.rdbtnHomem.Name = "rdbtnHomem";
            this.rdbtnHomem.Size = new System.Drawing.Size(61, 17);
            this.rdbtnHomem.TabIndex = 1;
            this.rdbtnHomem.Text = "Homem";
            this.rdbtnHomem.UseVisualStyleBackColor = true;
            // 
            // rdbtnMulher
            // 
            this.rdbtnMulher.AutoSize = true;
            this.rdbtnMulher.Checked = true;
            this.rdbtnMulher.Location = new System.Drawing.Point(3, 16);
            this.rdbtnMulher.Name = "rdbtnMulher";
            this.rdbtnMulher.Size = new System.Drawing.Size(57, 17);
            this.rdbtnMulher.TabIndex = 0;
            this.rdbtnMulher.TabStop = true;
            this.rdbtnMulher.Text = "Mulher";
            this.rdbtnMulher.UseVisualStyleBackColor = true;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(155, 147);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // mskTxtPeso
            // 
            this.mskTxtPeso.Location = new System.Drawing.Point(76, 32);
            this.mskTxtPeso.Mask = "00.00";
            this.mskTxtPeso.Name = "mskTxtPeso";
            this.mskTxtPeso.Size = new System.Drawing.Size(100, 20);
            this.mskTxtPeso.TabIndex = 6;
            // 
            // mskTxtAltura
            // 
            this.mskTxtAltura.Location = new System.Drawing.Point(76, 67);
            this.mskTxtAltura.Mask = "0.00";
            this.mskTxtAltura.Name = "mskTxtAltura";
            this.mskTxtAltura.Size = new System.Drawing.Size(100, 20);
            this.mskTxtAltura.TabIndex = 7;
            // 
            // txtPesoIdeal
            // 
            this.txtPesoIdeal.Enabled = false;
            this.txtPesoIdeal.Location = new System.Drawing.Point(76, 99);
            this.txtPesoIdeal.Name = "txtPesoIdeal";
            this.txtPesoIdeal.Size = new System.Drawing.Size(100, 20);
            this.txtPesoIdeal.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Peso ideal";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 205);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPesoIdeal);
            this.Controls.Add(this.mskTxtAltura);
            this.Controls.Add(this.mskTxtPeso);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbtnHomem;
        private System.Windows.Forms.RadioButton rdbtnMulher;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.MaskedTextBox mskTxtPeso;
        private System.Windows.Forms.MaskedTextBox mskTxtAltura;
        private System.Windows.Forms.TextBox txtPesoIdeal;
        private System.Windows.Forms.Label label3;
    }
}

