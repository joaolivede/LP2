﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double altura;
            double pesoAtual;
            double pesoIdeal = 0;

            if (!double.TryParse(mskTxtAltura.Text, out altura))
            {
                MessageBox.Show("Valor de altura inválido!");
                return;
            }
            else if (!double.TryParse(mskTxtPeso.Text, out pesoAtual))
            {
                MessageBox.Show("Valor de peso inválido!");
                return;
            }

            if (rdbtnMulher.Checked == true)
            {
                pesoIdeal = (altura * 62.1) - 44.7;
                txtPesoIdeal.Text = pesoIdeal.ToString("N2");
            }
            else
            {
                pesoIdeal = (altura * 72.7) - 58;
                txtPesoIdeal.Text = pesoIdeal.ToString("N2");
            }

            pesoIdeal = Math.Round(pesoIdeal, 2);

            if (pesoAtual > pesoIdeal)
            {
                MessageBox.Show("Regime Obrigatório Já!");
            }
            else if (pesoAtual < pesoIdeal)
            {
                MessageBox.Show("Coma bastante massas e doces!");
            }
            else
            {
                MessageBox.Show("Você está com o peso ideal!");
            }
        }
    }
}