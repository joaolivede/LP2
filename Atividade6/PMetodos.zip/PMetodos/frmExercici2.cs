﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercici2 : Form
    {
        public frmExercici2()
        {
            InitializeComponent();
        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            if (string.Compare(txtPalavra1.Text, txtPalavra2.Text) == 0)
            {
                MessageBox.Show("Palavras são iguais.");
            }
            else
            {
                MessageBox.Show("Palavras são diferentes");
            }
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            int lenTxt2 = txtPalavra2.Text.Length / 2;

            txtPalavra2.Text = txtPalavra2.Text.Substring(0, lenTxt2) + txtPalavra1.Text + txtPalavra2.Text.Substring(lenTxt2);
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            int lenTxt1 = txtPalavra1.Text.Length / 2;

            txtPalavra2.Text = txtPalavra1.Text.Insert(lenTxt1, "**");
        }
    }
}