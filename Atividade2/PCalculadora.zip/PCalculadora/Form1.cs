﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtResultado.Text = "";
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            if (ValidarNumeros())
            {
                txtResultado.Text = (Convert.ToDouble(txtNum1.Text) + Convert.ToDouble(txtNum2.Text)).ToString();
            }
            else
            {
                MessageBox.Show("Números inválidos");
            }
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            if (ValidarNumeros())
            {
                txtResultado.Text = (Convert.ToDouble(txtNum1.Text) - Convert.ToDouble(txtNum2.Text)).ToString();
            }
            else
            {
                MessageBox.Show("Números inválidos");
            }
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            if (ValidarNumeros())
            {
                txtResultado.Text = (Convert.ToDouble(txtNum1.Text) * Convert.ToDouble(txtNum2.Text)).ToString();
            }
            else
            {
                MessageBox.Show("Números inválidos");
            }
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            if (ValidarNumeros())
            {
                if (Convert.ToDouble(txtNum2.Text) == 0)
                {
                    MessageBox.Show("ERRO - Divisão por zero!");
                    return;
                }

                txtResultado.Text = (Convert.ToDouble(txtNum1.Text) / Convert.ToDouble(txtNum2.Text)).ToString();
            }
            else
            {
                MessageBox.Show("Números inválidos");
            }
        }

        private bool ValidarNumeros()
        {
            double num1, num2;

            if (double.TryParse(txtNum1.Text, out num1) && double.TryParse(txtNum2.Text, out num2))
            {
                return true;
            }

            return false;
        }
    }
}