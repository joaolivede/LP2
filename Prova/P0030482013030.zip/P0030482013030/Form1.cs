﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P0030482013030
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            int qtdMes = 10;
            double[,] vendas = new double[10, 4];
            string auxiliar;
            double valor;
            double valorTotal = 0;

            lstDados.Items.Clear();

            for (int i = 0; i < qtdMes; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox("Informe o valor das vendas da semana " + (j + 1).ToString() + " do mês " + (i + 1).ToString() + ".", "Infome os valores", "valor");

                    if (double.TryParse(auxiliar, out valor))
                    {
                        vendas[i, j] = valor;
                    }
                    else
                    {
                        if (auxiliar.Length == 0)
                        {
                            DialogResult diag = MessageBox.Show("Deseja cancelar?", "Cancelar", MessageBoxButtons.YesNo);

                            if (diag == DialogResult.Yes)
                            {
                                return;
                            }
                            else
                            {
                                j--;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Valor inválido");
                            j--;
                        }
                    }
                }
            }

            for (int i = 0; i < qtdMes; i++)
            {
                valor = 0;

                for (int j = 0; j < 4; j++)
                {
                    lstDados.Items.Add("Total do mês " + (i + 1).ToString() + " Semana: " + (j + 1) + " " + vendas[i, j].ToString("C2"));
                    valor += vendas[i, j];
                    valorTotal += vendas[i, j];
                }
                lstDados.Items.Add(">> Total do mês " + (i + 1).ToString() + ": " + valor.ToString("C2"));
                lstDados.Items.Add("----------------");
            }

            lstDados.Items.Add(">> Total Geral: " + valorTotal.ToString("C2"));
        }
    }
}