﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //checar se está vazio
            foreach (var control in this.Controls)
            {
                if (control is TextBox)
                {
                    if (((TextBox)control).Text == "")
                    {
                        MessageBox.Show(((TextBox)control).Name.Substring(3) + " não pode estar vazio!");
                        return;
                    }
                }
            }

            //converter em double

            double lado1;
            double lado2;
            double lado3;

            if (!double.TryParse(txtLado1.Text, out lado1))
            {
                MessageBox.Show("Lado1 não é um valor válido");
                return;
            }

            if (!double.TryParse(txtLado2.Text, out lado2))
            {
                MessageBox.Show("Lado2 não é um valor válido");
                return;
            }

            if (!double.TryParse(txtLado3.Text, out lado3))
            {
                MessageBox.Show("Lado3 não é um valor válido");
                return;
            }

            if ((lado1 < lado2 + lado3) && (lado2 < lado1 + lado3) && (lado3 < lado2 + lado1))
            {
                if (lado1 == lado2 && lado1 == lado3)
                {
                    MessageBox.Show("Triângulo equilátero");
                }
                else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3)
                {
                    MessageBox.Show("Triângulo isósceles");
                }
                else
                {
                    MessageBox.Show("Triângulo escaleno");
                }
            }
            else
            {
                MessageBox.Show("Valores informados não formam um triângulo!");
            }
        }
    }
}